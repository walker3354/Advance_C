#ifndef __MAIN__
#define __MAIN__

#include <stdio.h>
#include <stdlib.h>

#define TYPE_SMALL 0
#define TYPE_LARGE 1

#endif